package com.springsimplespasos.universidad.universidadbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversidadBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
