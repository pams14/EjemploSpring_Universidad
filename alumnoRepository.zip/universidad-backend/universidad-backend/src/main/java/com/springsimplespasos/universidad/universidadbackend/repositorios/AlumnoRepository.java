package com.springsimplespasos.universidad.universidadbackend.repositorios;

import org.springframework.stereotype.Repository;

@Repository("repositorioAlumnos")
public interface AlumnoRepository extends PersonaRepository {

}
