package com.springsimplespasos.universidad.universidadbackend.modelo.entidades.enumeradores;

public enum Pizarron {

    PIZARRON_TIZA,
    PIZARRON_BLANCA

}
