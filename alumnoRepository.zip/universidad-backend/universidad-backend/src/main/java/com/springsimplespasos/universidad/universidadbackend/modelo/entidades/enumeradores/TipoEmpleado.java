package com.springsimplespasos.universidad.universidadbackend.modelo.entidades.enumeradores;

public enum TipoEmpleado {

    ADMINISTRATIVO,
    MANTENIMIENTO

}
